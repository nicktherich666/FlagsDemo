import UIKit

var rect = CGRect(x: 0, y: 0, width: 200, height: 134)

// 國旗背景 (白色)
let backgroundView = UIView(frame: rect)
backgroundView.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 1)

rect = CGRect(x: (backgroundView.frame.width - 106)/2, y: (backgroundView.frame.height - 106) / 2, width: 106, height: 106)

let circleView = UIView(frame: rect)
circleView.backgroundColor = UIColor(red: 188/255, green: 0, blue: 45/255, alpha: 1)
circleView.layer.cornerRadius = 53
backgroundView.addSubview(circleView)

backgroundView
