import UIKit

var rect = CGRect(x: 0, y: 0, width: 255, height: 170)
let view = UIView(frame: rect)

// 韓國國旗白背景
let  whiteBackgroundPath = UIBezierPath()
whiteBackgroundPath.move(to: CGPoint(x: 0, y:0))
whiteBackgroundPath.addLine(to: CGPoint(x: 255, y: 0))
whiteBackgroundPath.addLine(to: CGPoint(x: 255, y: 170))
whiteBackgroundPath.addLine(to: CGPoint(x: 0, y: 170))
whiteBackgroundPath.close()

let whiteBackground = CAShapeLayer()
whiteBackground.strokeColor = UIColor.black.cgColor
whiteBackground.lineWidth = 1
whiteBackground.path = whiteBackgroundPath.cgPath
whiteBackground.fillColor = UIColor.white.cgColor
view.layer.addSublayer(whiteBackground)

view

// 紅色半圓
let aDegree = CGFloat.pi / 180
let redRoundpath = UIBezierPath(arcCenter:CGPoint(x: 127.5, y: 85), radius: 42.5, startAngle: aDegree * 45, endAngle: aDegree * 225, clockwise: false)

let redRoundlayer = CAShapeLayer()
redRoundlayer.path = redRoundpath.cgPath
redRoundlayer.fillColor = CGColor(red: 206/255, green: 42/255, blue: 55/255, alpha: 1)
view.layer.addSublayer(redRoundlayer)


// 藍色半圓
let blueRoundpath = UIBezierPath(arcCenter:CGPoint(x: 127.5, y: 85), radius: 42.5, startAngle: aDegree * 45, endAngle: aDegree * 225, clockwise: true )

let blueRoundlayer = CAShapeLayer()
blueRoundlayer.path = blueRoundpath.cgPath
blueRoundlayer.fillColor = CGColor(red: 0/255, green: 69/255, blue: 161/255, alpha: 1)
view.layer.addSublayer(blueRoundlayer)


// 紅色小半圓
let smallRedRoundpath = UIBezierPath(arcCenter:CGPoint(x: 127.5 - 21.25/sqrt(2),y: 85 - 21.25/sqrt(2)), radius: 42.5/2, startAngle: aDegree * 45, endAngle: aDegree * 225, clockwise: true )

let smallRedRoundlayer = CAShapeLayer()
smallRedRoundlayer.path = smallRedRoundpath.cgPath
smallRedRoundlayer.fillColor = CGColor(red: 206/255, green: 42/255, blue: 55/255, alpha: 1)
view.layer.addSublayer(smallRedRoundlayer)

view

// 藍色半圓
let smallBlueRoundpath = UIBezierPath(arcCenter:CGPoint(x: 127.5 + 21.25/sqrt(2),y: 85 + 21.25/sqrt(2)), radius: 42.5/2, startAngle: aDegree * 45, endAngle: aDegree * 225, clockwise: false)

let smallBlueRoundlayer = CAShapeLayer()
smallBlueRoundlayer.path = smallBlueRoundpath.cgPath
smallBlueRoundlayer.fillColor = CGColor(red: 0/255, green: 69/255, blue: 161/255, alpha: 1)
view.layer.addSublayer(smallBlueRoundlayer)

view


// 黑色長方形
let oneRect = threeBlackrect()
view.layer.addSublayer(oneRect)

let twoRect = threeBlackrect()
twoRect.setAffineTransform(CGAffineTransform(translationX: 130, y: 85))
view.layer.addSublayer(twoRect)

let threeRect = threeBlackrect()
threeRect.setAffineTransform(CGAffineTransform(translationX: 255, y: 0).scaledBy(x: -1, y: 1))
view.layer.addSublayer(threeRect)

let fourRect = threeBlackrect()
fourRect.setAffineTransform(CGAffineTransform(translationX: 125, y: 85).scaledBy(x: -1, y: 1))
view.layer.addSublayer(fourRect)

let whiteSpacePath = UIBezierPath()
whiteSpacePath.move(to: CGPoint(x: 59, y: 128))
whiteSpacePath.addLine(to: CGPoint(x: 65, y: 124))
whiteSpacePath.addLine(to: CGPoint(x: 66, y: 127))
whiteSpacePath.addLine(to: CGPoint(x: 60, y: 131))
whiteSpacePath.close()

whiteSpacePath.move(to: CGPoint(x: 181, y: 118))
whiteSpacePath.addLine(to: CGPoint(x: 206, y: 135))
whiteSpacePath.addLine(to: CGPoint(x: 204, y: 138))
whiteSpacePath.addLine(to: CGPoint(x: 179, y: 120))
whiteSpacePath.close()

whiteSpacePath.move(to: CGPoint(x: 197, y: 38))
whiteSpacePath.addLine(to: CGPoint(x: 205, y: 33))
whiteSpacePath.addLine(to: CGPoint(x: 207, y: 37))
whiteSpacePath.addLine(to: CGPoint(x: 199, y: 42))
whiteSpacePath.close()

whiteSpacePath.move(to: CGPoint(x: 185, y: 45))
whiteSpacePath.addLine(to: CGPoint(x: 178, y: 50))
whiteSpacePath.addLine(to: CGPoint(x: 180, y: 54))
whiteSpacePath.addLine(to: CGPoint(x: 188, y: 47))
whiteSpacePath.close()

let whiteSpaceLayer = CAShapeLayer()
whiteSpaceLayer.path = whiteSpacePath.cgPath
whiteSpaceLayer.fillColor = UIColor.white.cgColor
view.layer.addSublayer(whiteSpaceLayer)

view

func threeBlackrect() -> CALayer {
    let threeblackLayer = CALayer()

    let rect = blackrect()
  threeblackLayer.addSublayer(rect)

    let rect1 = blackrect()
    rect1.setAffineTransform(CGAffineTransform(translationX: 9, y: 7))
    threeblackLayer.addSublayer(rect1)

    let rect2 = blackrect()
    rect2.setAffineTransform(CGAffineTransform(translationX: 18, y: 14))
    threeblackLayer.addSublayer(rect2)

    return threeblackLayer
}

func blackrect() -> CALayer {

        let blacklayer = CALayer()

        // 黑色長方形
        let blackRectPath = UIBezierPath()
        blackRectPath.move(to: CGPoint(x: 38, y: 51))
        blackRectPath.addLine(to: CGPoint(x: 63, y: 17))
        blackRectPath.addLine(to: CGPoint(x: 68, y: 21))
        blackRectPath.addLine(to: CGPoint(x: 43, y: 55))
        blackRectPath.close()

        let blackRectLayer = CAShapeLayer()
        blackRectLayer.path = blackRectPath.cgPath
        blackRectLayer.fillColor = UIColor.black.cgColor
        blacklayer.addSublayer(blackRectLayer)

        return blacklayer
    }
